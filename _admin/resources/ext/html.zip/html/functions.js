function ResumeError() {
return true;
}
//window.onerror = ResumeError;
		var config,num,tdata;
	
		function resizex(iframe){
		iframe.height =0;
		iframe.height =  iframe.contentWindow.document.documentElement.scrollHeight;
		}
//gotop
function gotoTop(min_height){
    var gotoTop_html = '<div id="gotoTop">返回顶部</div>';
    $("#footer").append(gotoTop_html);
    $("#gotoTop").click(
        function(){$('html,body').animate({scrollTop:0},700);
    }).hover(
        function(){$(this).addClass("hover");},
        function(){$(this).removeClass("hover");
    });
    min_height ? min_height = min_height : min_height = 100;
    $(window).scroll(function(){
        var s = $(window).scrollTop();
        if( s > min_height){
            $("#gotoTop").fadeIn(100);
        }else{
            $("#gotoTop").fadeOut(200);
        };
    });
};

//写cookies
function setCookie(name,value)
{
var Days = 30;
var exp = new Date(); 
exp.setTime(exp.getTime() + Days*24*60*60*1000);
document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
}
//读取cookies
function getCookie(name)
{
var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
if(arr=document.cookie.match(reg)) return unescape(arr[2]);
else return null;
}
//删除cookies
function delCookie(name)
{
var exp = new Date();
exp.setTime(exp.getTime() - 1);
var cval=getCookie(name);
if(cval!=null) document.cookie= name + "="+cval+";expires="+exp.toGMTString();
}
function logout(){
delCookie("copycat_user");
delCookie("copycat_passwd");
window.location.href="login.html";
}
var isss;
$.post("index.php", {  op: "verify"},   function (data, textStatus){if((getCookie("copycat_user")!=data.user)||((getCookie("copycat_passwd"))!=data.passwd)){window.location.href="login.html";}else{if(document.getElementById("logname")){document.getElementById("logname").innerHTML=data.user+",";}}},"json");
$.post("index.php", {op: "readsite"},   function (data, textStatus){if(!isss&&!data){alert("请设置好当前站点！");window.location.href="site.html";}});

//setting
				function presave(table){
				
				var host=document.getElementById("host").value;
				var zdroot=document.getElementById("zdroot").checked;
				var root=document.getElementById("root").value;				
				var encoding=document.getElementById("encoding").selectedIndex;
				var thym=document.getElementById("thym").checked;
				var thnr=document.getElementById("thnr").checked;
				var ymys=document.getElementById("ymys").checked;
				var dwjdl=document.getElementById("dwjdl").checked;				
				var hckg=document.getElementById("hckg").checked;
				var hclx=document.getElementById("hclx").selectedIndex;
				var hcsx=(document.getElementById("hcsx").value)?(document.getElementById("hcsx").value):("3600");
				var zydhc=(document.getElementById("hcsx").value)?(document.getElementById("zydhc").value):("*");
				var csz=document.getElementById("csz").selectedIndex;
				var zydc=document.getElementById("zydc").value;
				var llqbzsz=document.getElementById("llqbzsz").selectedIndex;
				var zydllqbz=document.getElementById("zydllqbz").value;
				var llsz=document.getElementById("llsz").selectedIndex;
				var zydll=document.getElementById("zydll").value;
				var ipsz=document.getElementById("ipsz").selectedIndex;
				var zydip=document.getElementById("zydip").value;
				var dlsz=document.getElementById("dlsz").selectedIndex;
				var zyddl=document.getElementById("zyddl").value;				
				var hsz=document.getElementById("hsz").selectedIndex;
				var zydh=document.getElementById("zydh").value;	
				var rr='{"host":"'+b.encode(host)+'","zdroot":"'+b.encode(zdroot)+'","root":"'+b.encode(root)+'","encoding":"'+b.encode(encoding)+'","thym":"'+b.encode(thym)+'","thnr":"'+b.encode(thnr)+'","ymys":"'+b.encode(ymys)+'","dwjdl":"'+b.encode(dwjdl)+'","hckg":"'+b.encode(hckg)+'","hclx":"'+b.encode(hclx)+'","hcsx":"'+b.encode(hcsx)+'","zydhc":"'+b.encode(zydhc)+'","csz":"'+b.encode(csz)+'","zydc":"'+b.encode(zydc)+'","llqbzsz":"'+b.encode(llqbzsz)+'","zydllqbz":"'+b.encode(zydllqbz)+'","llsz":"'+b.encode(llsz)+'","zydll":"'+b.encode(zydll)+'","ipsz":"'+b.encode(ipsz)+'","zydip":"'+b.encode(zydip)+'","dlsz":"'+b.encode(dlsz)+'","zyddl":"'+b.encode(zyddl)+'","hsz":"'+b.encode(hsz)+'","zydh":"'+b.encode(zydh)+'"}';
				return b.encode(rr);
				}
					function preload(table,data){
				document.getElementById("host").value=b.decode(data.host);
				document.getElementById("zdroot").checked=((b.decode(data.zdroot)=="false")?(false):(true));
			   if(b.decode(data.zdroot)=='false'){
				document.getElementById("customcheckbox_zdroot").className="checkbox off";
				document.getElementById('zdrootp').style.display='block';
				//document.getElementById('hcp').style.display='block';
				}else{
					document.getElementById("customcheckbox_zdroot").className="checkbox on";
					//document.getElementById("hckg").onchange();
				}
				if((b.decode(data.zdroot)=='false')||((data.root)&&(b.decode(data.zdroot)=='false'))){
					document.getElementById("root").value=b.decode(data.root);				
				}else{
					$.post("../index.php", {op: "loadroot"},   function (data, textStatus){document.getElementById("root").value=data;});
				}
				document.getElementById("encoding").selectedIndex=b.decode(data.encoding);
				document.getElementById("thym").checked=((b.decode(data.thym)=="true")?(true):(false));
				//alert(b.decode(data.thym));
						if(b.decode(data.thym)=='true'){
				document.getElementById("customcheckbox_thym").className="checkbox on";
				//document.getElementById('hcp').style.display='block';
				}else{
					document.getElementById("customcheckbox_thym").className="checkbox off";
					//document.getElementById("hckg").onchange();
				}
				
				document.getElementById("thnr").checked=((b.decode(data.thnr)=="true")?(true):(false));
				//alert(b.decode(data.thym));
						if(b.decode(data.thnr)=='true'){
				document.getElementById("customcheckbox_thnr").className="checkbox on";
				//document.getElementById('hcp').style.display='block';
				}else{
					document.getElementById("customcheckbox_thnr").className="checkbox off";
					//document.getElementById("hckg").onchange();
				}
				
				document.getElementById("ymys").checked=((b.decode(data.ymys)=="true")?(true):(false));
				//alert(b.decode(data.thym));
						if(b.decode(data.ymys)=='true'){
				document.getElementById("customcheckbox_ymys").className="checkbox on";
				//document.getElementById('hcp').style.display='block';
				}else{
					document.getElementById("customcheckbox_ymys").className="checkbox off";
					//document.getElementById("hckg").onchange();
				}				
				
				document.getElementById("dwjdl").checked=((b.decode(data.dwjdl)=="true")?(true):(false));
				//alert(b.decode(data.thym));
						if(b.decode(data.dwjdl)=='true'){
				document.getElementById("customcheckbox_dwjdl").className="checkbox on";
				//document.getElementById('hcp').style.display='block';
				}else{
					document.getElementById("customcheckbox_dwjdl").className="checkbox off";
					//document.getElementById("hckg").onchange();
				}								
				
				document.getElementById("hckg").checked=((b.decode(data.hckg)=="true")?(true):(false));
				//alert(b.decode(data.hckg));
				if(b.decode(data.hckg)=='true'){
				document.getElementById("customcheckbox_hckg").className="checkbox on";
				document.getElementById('hcp').style.display='block';
				}else{
					document.getElementById("customcheckbox_hckg").className="checkbox off";
					//document.getElementById("hckg").onchange();
				}
				
					
					
				document.getElementById("hclx").selectedIndex=b.decode(data.hclx);
				document.getElementById("hclx").onchange();
		
				document.getElementById("hcsx").value=b.decode(data.hcsx);
				
				document.getElementById("zydhc").value=b.decode(data.zydhc);
				document.getElementById("csz").selectedIndex=b.decode(data.csz);
				document.getElementById("csz").onchange();
				document.getElementById("zydc").value=b.decode(data.zydc);
				document.getElementById("llqbzsz").selectedIndex=b.decode(data.llqbzsz);
				document.getElementById("llqbzsz").onchange();
				document.getElementById("zydllqbz").value=b.decode(data.zydllqbz);
				document.getElementById("llsz").selectedIndex=b.decode(data.llsz);
				document.getElementById("llsz").onchange();
				document.getElementById("zydll").value=b.decode(data.zydll);
				document.getElementById("ipsz").selectedIndex=b.decode(data.ipsz);
				document.getElementById("ipsz").onchange();
				document.getElementById("zydip").value=b.decode(data.zydip);
				document.getElementById("dlsz").selectedIndex=b.decode(data.dlsz);
				document.getElementById("dlsz").onchange();
				document.getElementById("zyddl").value=b.decode(data.zyddl);				
				document.getElementById("hsz").selectedIndex=b.decode(data.hsz);
				document.getElementById("hsz").onchange();
				document.getElementById("zydh").value=b.decode(data.zydh);				
				//alert(data.hclx);
				}
				function cleancache(config){
				$.post("index.php", {  op: "cleancache",config:config},   function (data, textStatus){alert(config+"缓存已清空");});
				}
				function delcache(dcp){
				$.post("../index.php", {delcache: dcp},   function (data, textStatus){alert(data);});
				}				
				function cachepath(config,isconfig){
				$.post("index.php", {  op: "cachepath",config:config,isconfig:isconfig},   function (data, textStatus){window.location.href="file.html#"+data});
				}				
				function saveconfig(table){
				var tt="0";
				if((window.location.hash.substring(1).length>0)&&(!confirm("是否启用为默认配置？"))){tt="1";}
$.post("index.php", {  op: "saveconfig",name:table,json:presave(table),type:tt},   function (data, textStatus){alert(table+" : "+data.result); if(window.location.hash.substring(1).length>0){window.location.href='users.html';}}, "json");
}
				function delconfig(table){

$.post("index.php", {  op: "delconfig",name:table},   function (data, textStatus){if(data.result){alert(table+" : "+"已删除"); window.location.href='users.html';}else{alert(table+" : "+"删除错误"); }}, "json");
}
function loadconfig(table){
$.post("index.php", {  op: "loadconfig",name:table},   function (data, textStatus){preload(table,data); },"json");
}

//page,path,replace
function bindEvent(){
$("td.editAble").unbind();
$("td.textEditor").bind("click",function(){
var val=$(this).html();
//$(this).html("<input type='text' style='width:100%' onblur='saveEdit(this)' value='"+val+"' >");
//$(this).children("input").select();
$(this).html("<textarea style='height:100%;width:100%;'  onblur='saveEdit(this)'>"+val+"</textarea>");
$(this).children("textarea").select();
$(this).unbind();
});
}
$(function(){
bindEvent();
});
function checkInput(str){
if(str){return true;}
}

function saveEdit(ctl){
if (checkInput(ctl)){
$(ctl).parent().html(htmlcl($(ctl).attr("value")));
$(ctl).parent().attr("orig",htmlcl($(ctl).attr("value")));
var pnt=$(ctl).parent();
$(pnt).html($(ctl).attr("value"));
$(pnt).attr("orig",$(ctl).attr("value"));
}
$(ctl).remove();
bindEvent();
}														

function checkqx(table){
var nn=0
for(var i=1;i<document.getElementById(table).rows.length;i++){
if(document.getElementById(table).rows[i].cells[0].getElementsByTagName('input')[0].checked){
nn++;
}
}
if((nn==(document.getElementById(table).rows.length-1))&&(document.getElementById(table).rows.length>1)){
document.getElementById(table).rows[0].cells[0].getElementsByTagName('input')[0].checked=true;
}else{
document.getElementById(table).rows[0].cells[0].getElementsByTagName('input')[0].checked=false;
}
}



function fnInsert(table,status,name,path,contents,issite){
					//alert(table);					
 var oTable = document.getElementById(table);
 var oTr = oTable.insertRow(-1);
 var oTd1 = oTr.insertCell(0);
  var oTd2 = oTr.insertCell(1);
   var oTd3 = oTr.insertCell(2);
    var oTd4 = oTr.insertCell(3);
	    var oTd5 = oTr.insertCell(4);
		    var oTd6 = oTr.insertCell(5);
	  oTable.rows[oTable.rows.length-1].innerHTML='<td><input onchange="if(this.checked){'+table+'.push(this.parentNode.parentNode.rowIndex);}else{'+table+'.remove(this.parentNode.parentNode.rowIndex);}checkqx(\''+table+'\');" type="checkbox" name="checkbox"></td><td>'+status+'</td><td  class="editAble textEditor" orig="'+htmlcl(name)+'" style="word-break: break-all">'+htmlcl(name)+'</td><td  class="editAble textEditor" orig="'+htmlcl(path)+'" style="word-break: break-all">'+htmlcl(path)+'</td><td  class="editAble textEditor" orig="'+htmlcl(contents)+'" style="word-break: break-all">'+htmlcl(contents)+'</td><td><a href="javascript:void(0);" onclick="this.parentNode.parentNode.parentNode.rows[this.parentNode.parentNode.rowIndex].cells[1].innerHTML=\'run\'" class="button"><small class="icon play"></small><span>play</span></a><a href="javascript:void(0);" onclick="this.parentNode.parentNode.parentNode.rows[this.parentNode.parentNode.rowIndex].cells[1].innerHTML=\'stop\'" class="button"><small class="icon stop"></small><span>stop</span></a><a href="javascript:void(0);" onclick="'+table+'.remove(this.parentNode.parentNode.rowIndex);this.parentNode.parentNode.parentNode.deleteRow(this.parentNode.parentNode.rowIndex);" class="button"><small class="icon cross"></small><span>delete</span></a><a href="javascript:void(0);" onclick="if(this.parentNode.parentNode.rowIndex>1){var s0=this.parentNode.parentNode.parentNode.rows[this.parentNode.parentNode.rowIndex-1].innerHTML;var s1=this.parentNode.parentNode.parentNode.rows[this.parentNode.parentNode.rowIndex].innerHTML;var ss=s0;this.parentNode.parentNode.parentNode.rows[this.parentNode.parentNode.rowIndex-1].innerHTML=s1;this.parentNode.parentNode.parentNode.rows[this.parentNode.parentNode.rowIndex].innerHTML=ss;}else{alert(\'toped\');}bindEvent();" class="button"><small class="icon arrow_up"></small><span>up</span></a><a href="javascript:void(0);" onclick="if(this.parentNode.parentNode.rowIndex<this.parentNode.parentNode.parentNode.rows.length-1){var s0=this.parentNode.parentNode.parentNode.rows[this.parentNode.parentNode.rowIndex+1].innerHTML;var s1=this.parentNode.parentNode.parentNode.rows[this.parentNode.parentNode.rowIndex].innerHTML;var ss=s0;this.parentNode.parentNode.parentNode.rows[this.parentNode.parentNode.rowIndex+1].innerHTML=s1;this.parentNode.parentNode.parentNode.rows[this.parentNode.parentNode.rowIndex].innerHTML=ss;}else{alert(\'ended\');}bindEvent();" class="button"><small class="icon arrow_down"></small><span>down</span></a>'+((issite)?('<div style="line-height: 32px;"><br><a href="javascript:void(0);" onclick="cleancache(\''+contents+'\');" class="button"><small class="icon unfavorite"></small><span>cacheclean</span></a><a href="javascript:void(0);" onclick="cachepath(\''+contents+'\');" class="button"><small class="icon documents"></small><span>cacheview</span></a><a href="javascript:void(0);" onclick="cachepath(\''+contents+'\',1);" class="button"><small class="icon favorite"></small><span>configview</span></a></div>'):(''))+'</td>';
	  bindEvent();
}

				





Array.prototype.indexOf = function(val) {
            for (var i = 0; i < this.length; i++) {
                if (this[i] == val) return i;
            }
            return -1;
        };
        Array.prototype.remove = function(val) {
            var index = this.indexOf(val);
            if (index > -1) {
                this.splice(index, 1);
            }
        };

function plsz(sz){

var newarray=[];
var oldarray=sz;
var max=0;
var nn=sz.length;
while (newarray.length<nn){

for(var i=0;i<oldarray.length;i++){
if(oldarray[i]>max){
max=oldarray[i];

}

}
newarray.push(max);
oldarray.remove(max);
max=0;
}
//alert(newarray.join(","));
return newarray;
}
function gjsn(status,name,path,contents){
/*alert(status);
alert(name);
alert(path);
alert(contents);*/
var rr=',{"status":"'+b.encode(status)+'","name":"'+b.encode(name)+'","path":"'+b.encode(path)+'","contents":"'+b.encode(contents)+'"}';

return rr;
}
var b =new  Base64() ;



function loadsetting(table,jsn){
 var ss=JSON.parse(jsn);
 //alert(b.decode(ss[0].contents));
try{

var tb = document.getElementById(table);
     var rowNum=tb.rows.length;
     for (i=1;i<rowNum;i++) 
     {
         tb.deleteRow(i);
         rowNum=rowNum-1;
         i=i-1;
     }
}catch(e){}
 for(var i=0;i<ss.length;i++){
 var xisset=0;
 if(table=="site"){xisset=1;}
fnInsert(table,b.decode(ss[i].status),b.decode(ss[i].name),b.decode(ss[i].path),b.decode(ss[i].contents),xisset);
}
}
function savesetting(table){
var ztt=document.getElementById(table).rows[i];
var jsn='[';for(var i=1;i<document.getElementById(table).rows.length;i++){jsn+=gjsn(htmlcl(document.getElementById(table).rows[i].cells[1].innerHTML,1),htmlcl(document.getElementById(table).rows[i].cells[2].innerHTML,1),htmlcl(document.getElementById(table).rows[i].cells[3].innerHTML,1),htmlcl(document.getElementById(table).rows[i].cells[4].innerHTML,1));}jsn+=']';jsn=jsn.replace('[,','[');
return jsn;
}



function save(table,issite){
if(!issite){issite=0;}
$.post("index.php", {  op: "save",name:table,json:b.encode(savesetting(table)),site:issite},   function (data, textStatus){alert(table+" : "+data.result); }, "json");
}
function load(table,issite){
if(!issite){issite=0;}
$.post("index.php", {  op: "load",name:table,site:issite},   function (data, textStatus){loadsetting(table,data); });
}


//articles
function htmlcl(str,fz){
if(!fz){
return str.replace(/\&/g,"&amp;").replace(/\"/ig,"&quot;").replace(/\'/g, "&#39;").replace(/\</ig,"&lt;").replace(/\>/ig,"&gt;");
}else{
return str.replace(/\&gt\;/ig,">").replace(/\&lt\;/ig,"<").replace(/\&\#39\;/ig,"'").replace(/\&quot\;/ig,"\"").replace(/\&amp\;/ig,"&");
}
}
function delpage(table){

$.post("index.php", {  op: "delpage",name:table},   function (data, textStatus){if(data.result){alert(table+" : "+"已删除"); window.location.href='articles.html';}else{alert(table+" : "+"删除错误"); }},"json");
}
function viewbox(table){
		document.getElementById('edit').style.display="block";
		document.getElementById('ttll').innerHTML='<h2 style="overflow:hidden">'+htmlcl((table.length>15)?(table.substring(0,15)+"..."):(table))+' - 编辑模板<a href="javascript:void(0);" onclick="delpage(\''+table.trim()+'\');"><span style="right:40px">Delete</span></a>&nbsp;<a href="javascript:void(0);" onclick="document.getElementById(\'editor\').src=\'\';document.getElementById(\'edit\').style.display=\'none\';"><span>Close</span></a></h2>';
		document.getElementById('editor').src="index.php?op=editor&name="+table;
		
		}
		function loadpp(data){
		var sx="";
		var ch=parseInt(data.length/5);
		if(ch*5<data.length){ch++;}
		for(var i=0;i<ch;i++){
		sx+='<div class="shelf"><div class="left"></div><div class="right"></div><div class="inside"><div class="books articles">';
		for(var x=0;x<5;x++){
		var xxz=data[i*5+x];
		if(xxz){
		sx+='<div class="col w2"><a href="javascript:void(0);" onclick="viewbox(\''+xxz[0]+'\');" ><span style="overflow:hidden"><div align="center">'+xxz[2]+'</div>'+htmlcl(xxz[0])+'</span><small style="overflow:hidden;word-wrap: break-word;">'+xxz[1]+'</small></a></div>';
		}
		}
		sx+='</div></div><div class="clear"></div></div>';
		}
		document.getElementById("zw").innerHTML=sx;
		}
		function searchuserp(key){
		if(key){
		var dd=[];
		for(var i=0;i<num;i++){
		if((tdata[i][0].length>tdata[i][0].replace(key,"").length)||((tdata[i][1].length>tdata[i][1].replace(key,"").length))||((tdata[i][2].length>tdata[i][2].replace(key,"").length))){
		dd.push(tdata[i]);
		}
		}
		loadpp(dd);
		}else{
		loadpp(tdata);
		}
		}
		
		//user
		function loadss(data){
		var sx="";
		var ch=parseInt(data.length/5);
		if(ch*5<data.length){ch++;}
		for(var i=0;i<ch;i++){
		sx+='<div class="shelf"><div class="left"></div><div class="right"></div><div class="inside"><div class="books">';
		for(var x=0;x<5;x++){
		var xxz=data[i*5+x];
		if(xxz){
		sx+='	<div class="col w2"><a href="setting.html#'+xxz+'"><span>'+xxz+((xxz==config)?("[启用]"):(""))+'</span><img src="images/shelf_sample_image.png" height="108px" alt="" /></a></div>';
		}
		}
		sx+='</div></div><div class="clear"></div></div>';
		}
		document.getElementById("zw").innerHTML=sx;
		}
	function searchuseru(key){
		if(key){
		var dd=[];
		for(var i=0;i<num;i++){
		if((tdata[i].length>tdata[i].replace(key,"").length)){
		dd.push(tdata[i]);
		}
		}
		loadss(dd);
		}else{
		loadss(tdata);
		}
		}		
		
    //site
	function loaduser(){
	   $.post("index.php", {op: "loaduser"},   function (data, textStatus){ var data=JSON.parse(data);document.getElementById("user").value=data.user;document.getElementById("passwd").value=data.passwd; });
	}	
	function saveuser(){
	if(document.getElementById("user").value&&document.getElementById("user").value){
	   $.post("index.php", {op: "saveuser",user:document.getElementById("user").value,passwd:document.getElementById("passwd").value},   function (data, textStatus){alert("Done!");window.location.reload();});
	}
	}
    function loadqjcookie(){
	$.post("index.php", {op: "loadqjcookie"},   function (data, textStatus){document.getElementById("qjc").value=data});
	}	
    function saveqjcookie(){
	$.post("index.php", {op: "saveqjcookie",data:document.getElementById("qjc").value},   function (data, textStatus){alert("Done!");});
	}		
    function loadhtaccess(){
	$.post("index.php", {op: "loadhtaccess"},   function (data, textStatus){document.getElementById("data").value=data});
	}	
    function savehtaccess(){
	$.post("index.php", {op: "savehtaccess",data:document.getElementById("data").value},   function (data, textStatus){alert("Done!");});
	}	
    function backhtaccess(){
	$.post("index.php", {op: "backhtaccess"},   function (data, textStatus){document.getElementById("data").value=data});
	}	
	function cronstart(){
	$.get("cron.php",   function (data, textStatus){alert(data);});
	}
	function cronstop(){
	$.post("cron.php", {cron: "stop"},   function (data, textStatus){alert(data);});
	}	
	function croncheck(){
	$.post("cron.php", {cron: "checkurl"},   function (data, textStatus){if(prompt("监控外链",data)){$.post("cron.php", {cron: "check"},   function (data, textStatus){alert(data);});}});
	}	
	function changeadminpath(xnad){
	$.post("index.php", {op: "changeadminpath",nad:xnad},   function (data, textStatus){window.location.href="../"+data+"/site.html"});
	}			
	function readadminpath(){
	$.post("index.php", {op: "readadminpath"},   function (data, textStatus){var xx=prompt('请输入新的后台系统目录:',data);if(xx){if(xx!=data){changeadminpath(xx);}else{alert("请输入新的后台系统目录！");}}});
	}		
//help

	function getzy(str){
	$.post("index.php", {op: "getzy",str:str},   function (data, textStatus){prompt("转义结果:",data);});
	}		